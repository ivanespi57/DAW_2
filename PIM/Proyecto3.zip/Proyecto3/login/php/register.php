<?php
session_start();
header("Content-Type: application/json");

// ----------------------------
// 1. CONEXIÓN A LA BASE DE DATOS
// ----------------------------
$servername = "localhost";
$username   = "ivan";     // ← TU USUARIO MYSQL
$password   = "1234";     // ← TU CONTRASEÑA MYSQL
$dbname     = "login";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode([
        "success" => false,
        "message" => "Error DB: ".$conn->connect_error
    ]);
    exit;
}

// ----------------------------
// 2. RECIBIR DATOS DEL FETCH()
// ----------------------------
$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data["user"], $data["pass"], $data["codigo"])) {
    echo json_encode([
        "success" => false,
        "message" => "Datos incompletos"
    ]);
    exit;
}

$user   = $data["user"];
$pass   = $data["pass"];
$codigo = $data["codigo"];

// ----------------------------
// 3. COMPROBAR SI EL USUARIO EXISTE
// ----------------------------
$check = $conn->prepare("SELECT user FROM usuarios WHERE user = ?");
$check->bind_param("s", $user);
$check->execute();
$res = $check->get_result();

if ($res->num_rows > 0) {
    echo json_encode([
        "success" => false,
        "message" => "El usuario ya existe"
    ]);
    exit;
}

// ----------------------------
// 4. ENCRIPTAR CONTRASEÑA
// ----------------------------
$hash = password_hash($pass, PASSWORD_DEFAULT);

// ----------------------------
// 5. INSERTAR EL USUARIO
// ----------------------------
$sql = $conn->prepare("INSERT INTO usuarios (user, password, codigo) VALUES (?, ?, ?)");
$sql->bind_param("sss", $user, $hash, $codigo);

if ($sql->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Registrado correctamente"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Error BD: " . $conn->error
    ]);
}
exit;
?>
