<?php
    session_start();
    header("Content-Type: application/json");

    // ----------------------------
    // 1. CONEXIÓN A LA BASE DE DATOS
    // ----------------------------
    $servername = "localhost";
    $username   = "ivan";     // ← TU USUARIO MYSQL
    $password   = "1234";     // ← TU CONTRASEÑA MYSQL
    $dbname     = "login";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        echo json_encode([
            "success" => false, 
            "message" => "Error DB: " . $conn->connect_error
        ]);
        exit;
    }

    // ----------------------------
    // 2. RECIBIR JSON DEL FETCH()
    // ----------------------------
    $data = json_decode(file_get_contents("php://input"), true);

    if (!$data || !isset($data["user"], $data["pass"])) {
        echo json_encode([
            "success" => false,
            "message" => "Datos inválidos"
        ]);
        exit;
    }

    $user = $data["user"];
    $pass = $data["pass"];

    // ----------------------------
    // 3. BUSCAR USUARIO EN LA BBDD
    // ----------------------------
    $sql = $conn->prepare("SELECT password FROM usuarios WHERE user = ?");
    $sql->bind_param("s", $user);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows === 0) {
        echo json_encode([
            "success" => false,
            "message" => "Usuario no encontrado"
        ]);
        exit;
    }

    $row = $result->fetch_assoc();
    $hash = $row["password"];

    // ----------------------------
    // 4. VERIFICAR CONTRASEÑA
    // ----------------------------
    if (!password_verify($pass, $hash)) {
        echo json_encode([
            "success" => false,
            "message" => "Contraseña incorrecta"
        ]);
        exit;
    }

    // ----------------------------
    // 5. LOGIN CORRECTO
    // ----------------------------
    $_SESSION["user"] = $user;

    echo json_encode([
        "success" => true,
        "message" => "Login correcto"
    ]);
    exit;
?>
