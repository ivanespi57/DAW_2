<?php
/***
 * Formulario para registrar un aprendiz de Hogwarts
 * Requiere sesión para guardar los datos entre peticiones 
 * y un token CSRF para evitar ataques.
 * Se debe validar usando el fichero validaciones.php
 **/

/**
 * PROCESAR FORMULARIO
 */



    // Comprobar token CSRF y finalizar si no es válido
   

    // Si se pulsa ENVIAR
    
        
        /**
         * GUARDAR EN BASE DE DATOS
         * Los datos ya están validados y se guardan en sesión ($_SESSION)
         * Se redirige a resultado.php con el id del aprendiz
         */
       

    // Si se pulsa VALIDAR
    
        /**
         * VALIDACIONES y guardar valores en sesión
         */

        //nombre
       
        //casa 
       

        //varita
        

        //asignaturas
       

        //nivel mágico
        

        //foto

        //Si no hay foto en sesión, validamos la subida

            // Validar que se ha subido una foto
           
                // Validar extensiones y tamaño de la foto.
                //Si todo OK, guardar datos de la foto en sesión
                
                    /***
                     * GUARDAR LA FOTO EN EL SERVIDOR
                     */
                    
                    //Si no existe se crea la carpeta Uploads
                    
                    //Generamos el nombre final del archivo
                   
                    // nombreAprendiz_timestamp.extensión es el formato final
                   

                    // Mover el archivo subido a la carpeta uploads
                    
                    // Guardar el nombre final en sesión
                    
             //fin validación foto subida
         //fin foto en sesión
     //fin botón validar
  
?>
<!-- FORMULARIO HTML, pon tu nombre con h1 -->



<!-- El listado de errores si los hay -->

<!-- completar las opciones necesarias del formulario -->
<form action="index.php" method="XXX" >
    <!-- Campo oculto para el token CSRF -->
    <input type="XXX" name="token" value="">
    <!-- En cada campo debemos devolver los datos correctos 
        $_SESSION['nombre'] ?? '' Si no hay valor en la sesión devolvemos vacío para no devolver null -->
    <p><label>Nombre del aprendiz:</label>

    </p>

    <p><label>Casa:</label>
    
    </p>

   <p><label>Varita:</label>
    
    </p>

   <p><label>Asignaturas favoritas:</label>
      
    
    </p>

   <p><label>Nivel mágico (1-100):</label>
   
    </p>
    <!-- Campo para subir la foto -->
    <!-- Si ya hay foto en sesión, no mostramos el campo de subida -->
    
    <p><label>Foto del aprendiz:</label>

    </p>
    <!-- Campo oculto para el tamaño máximo de la foto (2MB) -->
    <input type="hidden" name="tamano_maximo" value="2000000">

    <br><br>

    <!-- VALIDAR visible si:
         - NO es POST
         - O es POST con errores -->
   
        <button type="submit" name="validar">VALIDAR</button>
  

    <!-- ENVIAR visible si:
         - ES POST
         - Y NO hay errores -->
   
        <button type="submit" name="enviar">ENVIAR</button>
 
</form>
