<?php

class Aprendiz {
    /**
     * Clase modelo para representar un aprendiz de Hogwarts
     * Atributos: nombre, casa, varita, asignaturas, nivel, foto
     * Métodos: __construct, guardar()
    */

    public function __construct($datos) {
    /**
    * Inicializa un nuevo aprendiz con los datos proporcionados
    */
    }

    public function guardar() {
    /**
     * Guarda el aprendiz en la base de datos
     * Devuelve el ID del aprendiz insertado
     */
    }

}
