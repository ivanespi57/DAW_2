<?php
    session_start();

    require_once __DIR__ . '/../database/database.php';
    require_once __DIR__ . '/../models/Aprendiz.php';
    require_once __DIR__ . '/../../validaciones.php';

    // Solo aceptamos peticiones POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        header('Location: ../../public/index.php');
        exit;
    }
    function limpiarSesionFormulario(): void{
        unset($_SESSION['datos_form'], $_SESSION['errores'], $_SESSION['foto'], $_SESSION['aprendiz']);
    }
    function validarFormularioAprendiz(array $datos, array &$errores = []): array{
        $limpios = [];

        $nombre = trim($datos['nombre'] ?? '');
        if ($nombre === '') {
            $errores['nombre'] = 'El nombre es obligatorio.';
        }
        $limpios['nombre'] = htmlspecialchars($nombre, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

        $nivel = trim($datos['nivel'] ?? '');
        if ($nivel !== '') {
            if (!ctype_digit($nivel) || (int)$nivel < 10 || (int)$nivel > 120) {
                $errores['nivel'] = 'La nivel debe ser un número entre 10 y 120.';
            } else {
                $limpios['nivel'] = (int)$nivel;
            }
        } else {
            $limpios['nivel'] = null;
        }

        $casa = $datos['casa'] ?? '';
        if ($casa === '') {
            $errores['casa'] = 'Debes seleccionar un casa';
        }
        $limpios['casa'] = $casa;

        $varita = $datos['varita'] ?? [];
        if (!is_array($varita)) {
            $varita = [];
        }
        $limpios['varita'] = $varita;

        $asigna = $datos['asigna'] ?? [];
        if (!is_array($asigna)) {
            $asigna = [];
        }
        $limpios['asigna'] = $asigna;

        // Guardamos datos limpios en sesión para recargar el formulario
        $_SESSION['datos_form'] = $limpios;

        return $limpios;
    }

class AprendizController {

    public function guardar($datosFormulario) {
        /***
         * Crear una instancia del modelo Aprendiz 
         * y guardar el aprendiz en la base de datos
         */



        // Acción recibida desde el formulario
        $accion = $_POST['accion'] ?? '';

        switch ($accion) {
            case 'eliminar':
                // Acción: limpiar sesión del formulario y volver al inicio
                limpiarSesionFormulario();
                header('Location: ../../public/index.php');
                exit;

            case 'validar':
                // Comprobamos token CSRF
                $tokenEnviado = $_POST['token'] ?? '';
                if (!verificarToken($tokenEnviado)) {
                    $_SESSION['errores']['token'] = 'Token inválido. Recarga el formulario.';
                    header('Location: ../../public/index.php');
                    exit;
                }

                // Validamos campos del formulario
                $errores = [];
                $datosLimpios = validarFormularioAprendiz($_POST, $errores);

                // Volvemos siempre al formulario con los errores (si los hay)
                $_SESSION['errores'] = $errores;
                header('Location: ../../public/index.php');
                exit;

            case 'enviar':
            default:
                // Comprobamos token CSRF
                $tokenEnviado = $_POST['token'] ?? '';
                if (!verificarToken($tokenEnviado)) {
                    $_SESSION['errores']['token'] = 'Token inválido. Recarga el formulario.';
                    header('Location: ../../public/index.php');
                    exit;
                }

                // Validamos campos del formulario
                $errores = [];
                $datosLimpios = validarFormularioAprendiz($_POST, $errores);

                // Si hay errores no enviamos nada
                if (!empty($errores)) {
                    $_SESSION['errores'] = $errores;
                    header('Location: ../../public/index.php');
                    exit;
                }

                // Subimos imagen
                $rutaFoto = subirImagen('imagen', '../../public/uploads/');
                if ($rutaFoto !== false) {
                    $datosLimpios['foto'] = $rutaFoto;
                }

                $datosRol = [];
                $aprendiz = new Aprendiz($datosLimpios, $datosRol);

                // Insertamos el aprendiz en la tabla de la base de datos.
                try {
                    $asignaTexto = implode(',', $aprendiz->getasigna());

                    $sql = "INSERT INTO aprendiz 
                        (nombre, nivel, casa, varita, asigna, foto)
                        VALUES
                        (:nombre, :nivel, :casa, :varita, :asigna, :foto)";

                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([
                        ':nombre'      => $aprendiz->getNombre(),
                        ':nivel'        => $aprendiz->getNivel(),
                        ':casa'         => $aprendiz->getCasa(),
                        ':varita'      => $aprendiz->getVarita(),
                        ':asigna' => $asignaTexto,
                        ':foto'        => $aprendiz->getRutaFoto(),
                    ]);
                } catch (PDOException $e) {
                    $_SESSION['errores']['bd'] = 'Error al guardar el aprendiz en la base de datos.';
                    header('Location: ../../public/index.php');
                    exit;
                }

                $_SESSION['aprendiz'] = json_encode(
                    $aprendiz->toArray(),
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                );

                // Limpiamos errores, ya que el envío ha sido correcto
                unset($_SESSION['errores']);

                header('Location: ../../public/resultado.php');
                exit;
         }

    }
}
