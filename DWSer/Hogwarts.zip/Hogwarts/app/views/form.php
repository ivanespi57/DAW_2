<?php
/***
 * Formulario para registrar un aprendiz de Hogwarts
 * Requiere sesión para guardar los datos entre peticiones 
 * y un token CSRF para evitar ataques.
 * Se debe validar usando el fichero validaciones.php
 **/
require_once 'validaciones.php';

/**
 * PROCESAR FORMULARIO
 */



    // Comprobar token CSRF y finalizar si no es válido
    $datos   = $_SESSION['datos_form'] ?? [];
    $errores = $_SESSION['errores'] ?? [];

    if (!isset($_SESSION['token'])) {
        $_SESSION['token'] = bin2hex(openssl_random_pseudo_bytes(24));
	    return $_SESSION['token'];
    }

    // Si se pulsa ENVIAR
    
        
        /**
         * GUARDAR EN BASE DE DATOS
         * Los datos ya están validados y se guardan en sesión ($_SESSION)
         * Se redirige a resultado.php con el id del aprendiz
         */
       

    // Si se pulsa VALIDAR
    
        /**
         * VALIDACIONES y guardar valores en sesión
         */
        $usu = "";
        $pass = "";
        $nom = "";
        $email = "";
        $direc = "";
        $CP = "";
        $rol = "";
        $tipoAloj[] = "";
        $serv[] = "";
        $alquiler = "";
        $foto = "";
        //nombre
       
        //casa 
       

        //varita
        

        //asignaturas
       

        //nivel mágico
        

        //foto

        //Si no hay foto en sesión, validamos la subida

            // Validar que se ha subido una foto
           
                // Validar extensiones y tamaño de la foto.
                //Si todo OK, guardar datos de la foto en sesión
                
                    /***
                     * GUARDAR LA FOTO EN EL SERVIDOR
                     */
                    
                    //Si no existe se crea la carpeta Uploads
                    
                    //Generamos el nombre final del archivo
                   
                    // nombreAprendiz_timestamp.extensión es el formato final
                   

                    // Mover el archivo subido a la carpeta uploads
                    
                    // Guardar el nombre final en sesión
                    
             //fin validación foto subida
         //fin foto en sesión
     //fin botón validar
  
?>
<!-- FORMULARIO HTML, pon tu nombre con h1 -->

<h1>Iván Espí Asins</h1>

<!-- El listado de errores si los hay -->

<!-- completar las opciones necesarias del formulario -->
<form action="../app/controllers/AprendizControllers.php" method="multipart/form-data" >
    <!-- Campo oculto para el token CSRF -->
    <input type="XXX" name="token" value="">
    <!-- En cada campo debemos devolver los datos correctos 
        $_SESSION['nombre'] ?? '' Si no hay valor en la sesión devolvemos vacío para no devolver null -->
        <?php if ($errores): ?>
            <ul style="color: #f00;">
            <?php foreach ($errores as $error): ?>
            <li> <?php echo $error ?> </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
    <p><label>Nombre del aprendiz:</label>
        <input type="text" name="nombre" value="<?= valor('nombre'); ?>">
        <?php if (tieneError('nombre')): ?><span class="error"><?= textoError('nombre'); ?></span><?php endif; ?>
    </label>
    </p>

    <p><label>Casa:</label>
        <select name="casa">
            <option value="">-- Elige tu casa --</option>
            <option value="Gryffindor" <?= in_array("Gryffindor", $casa) ? "selected" : "" ?>>Gryffindor</option>
            <option value="Slytherin" <?= in_array("Slytherin", $casa) ? "selected" : "" ?>>Slytherin</option>
            <option value="Hufflepuff"<?= in_array("Hufflepuff", $casa) ? "selected" : "" ?>>Hufflepuff</option>
            <option value="Ravenclaw" <?= in_array("Ravenclaw", $casa) ? "selected" : "" ?>>Ravenclaw</option>
        </select>
    </p>

   <label>Varita
        <input type="checkbox" name="varita[]" value="Roble con núcleo de fénix"<?= in_array("Roble con núcleo de fénix", $varita) ? "checked" : "" ?>> Roble con núcleo de fénix<br>
        <input type="checkbox" name="varita[]" value="Sauce con núcleo de unicornio"<?= in_array("Sauce con núcleo de unicornio", $varita) ? "checked" : "" ?>> Sauce con núcleo de unicornio<br>
        <input type="checkbox" name="varita[]" value="Acebo con núcleo de dragón"<?= in_array("Acebo con núcleo de dragón", $varita) ? "checked" : "" ?>> Acebo con núcleo de dragón<br>
    </label>

    <p>Asignaturas favoritas</p>
    <label>
        <input type="checkbox" name="asigna[]" value="pociones"> Pociones
    </label>
    <label>
        <input type="checkbox" name="asigna[]" value="Herbologia" > Herbologia
    </label>
    <label>
        <input type="checkbox" name="asigna[]" value="encantamientos" > Encantamientos
    </label>
    <label>
        <input type="checkbox" name="asigna[]" value="defensa" > Defensa contra las Artes Oscuras
    </label>

   <p><label>Nivel mágico (1-100):</label>
            <input type="text" name="nivel">
    </p>
    <!-- Campo para subir la foto -->
    <!-- Si ya hay foto en sesión, no mostramos el campo de subida -->
    
    <p><label>Foto del aprendiz:</label>
        <input type='file' name='imagen'><br/>
    </p>
    <!-- Campo oculto para el tamaño máximo de la foto (2MB) -->
    <input type="hidden" name="tamano_maximo" value="2000000">

    <br><br>

    <!-- VALIDAR visible si:
         - NO es POST
         - O es POST con errores -->
   
        <button type="submit" name="validar">VALIDAR</button>
  

    <!-- ENVIAR visible si:
         - ES POST
         - Y NO hay errores -->
   
        <button type="submit" name="enviar">ENVIAR</button>
 
</form>
